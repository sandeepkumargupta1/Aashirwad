"""Aashirwad local agricultural API."""
